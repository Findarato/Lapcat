LESS CSS Preprocessor

Files in lessphp/ are from the library at http://leafo.net/lessphp/

The LICENSE file in lessphp/ applies only to files within lessphp/


DIRECTIONS:

Can be invoked by either

drupal_add_css('filename.less')

or

stylesheets[all] = filename.less