<?php 
/*
 * Available vars:
 * $image containing the thumbnail and the image
 * $image_meta containing more info about the image
 */
?>
<div class="flickr-wrap-image">
  <?php print $image['image']; ?>
</div>