var assert = require('assert');

describe('user-select', function() {

  it('should return the same value', function(done) {
    test.userSelect('none', 'none', done);
  });

});
