var assert = require('assert');

describe('align-self', function () {

  it('should return start', function (done) {
    test.alignSelf.ms('flex-start', 'start', done);
  });

});
