var assert = require('assert');

describe('justify-content', function () {

  /**
   * If you want to test this code, comment 'justifyContent.result' from justify-content.js
   */
  // it('should return distribute value', function (done) {
  //   test.justifyContent.ms('space-around', 'distribute', done);
  // });

});