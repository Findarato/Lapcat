var assert = require('assert');

describe('background-image', function () {

  /**
   * If you want to test gradients, just remove 'prefixed: false' from background-image.js file
   */

  // it('should return the same value', function (done) {
  //   test.backgroundImage('linear-gradient(right, #1e5799 0%, #7db9e8 100%)', 'linear-gradient(to left, #1e5799 0%, #7db9e8 100%)', done);
  // });

  // it('should add prefix and return the value', function (done) {
  //   test.backgroundImage.webkit('linear-gradient(to right, #1e5799 0%, #7db9e8 100%)', '-webkit-linear-gradient(left, #1e5799 0%, #7db9e8 100%)', done);
  // });

  // it('should convert angle for older webkit syntax', function (done) {
  //   test.backgroundImage.webkit('linear-gradient(40deg, #1e5799 0%, #7db9e8 100%)', '-webkit-linear-gradient(50deg, #1e5799 0%, #7db9e8 100%)', done);
  // });

  // it('should convert new radial gradient syntax to older version', function (done) {
  //   test.backgroundImage.webkit('radial-gradient(circle closest-side at 20px 30px, #000000 0%, #ffffff 25%)', '-webkit-radial-gradient(20px 30px,circle contain, #000000 0%, #ffffff 25%)', done);
  // });

  // it('should add prefix, convert new radial gradient syntax to older version and convert angle for linear gradient', function (done) {
  //   test.backgroundImage.webkit('radial-gradient(circle closest-side at 20px 30px, #000000 0%, #ffffff 25%), linear-gradient(40deg, #1e5799 0%, #7db9e8 100%)', '-webkit-radial-gradient(20px 30px,circle contain, #000000 0%, #ffffff 25%), -webkit-linear-gradient(50deg, #1e5799 0%, #7db9e8 100%)', done);
  // });

});