var assert = require('assert');

describe('order', function () {

  it('should return the same value', function (done) {
    test.order('1', '1', done);
  });

});