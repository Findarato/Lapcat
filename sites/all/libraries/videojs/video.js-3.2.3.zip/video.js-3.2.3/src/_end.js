
// Expose to global
window.VideoJS = window._V_ = VideoJS;

// End self-executing function
})(window);