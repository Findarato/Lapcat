var vjsSourceList = [];
