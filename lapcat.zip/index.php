<?Php
include "smarty.inc.php";
$smarty -> display('index.tpl');
?>